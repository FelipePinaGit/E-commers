-- AlterTable
ALTER TABLE `venta` ADD COLUMN `estado` VARCHAR(191) NOT NULL DEFAULT 'activa';
